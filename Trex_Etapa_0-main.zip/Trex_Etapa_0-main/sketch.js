
var trex ,trex_running;
function preload(){
  

}

function setup(){
  createCanvas(600,200)
  
  //crear sprite del t-rex.
 
}

function draw(){
  background("white")
  

}
